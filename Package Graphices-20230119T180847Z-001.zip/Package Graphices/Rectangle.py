def arearect(l,b):
    print("Area of Reactangle is:",l*b)
def areaper(l,b):
    print("Rectangle perimeter is:",2*l+b)