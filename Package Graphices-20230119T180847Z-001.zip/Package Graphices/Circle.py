def areacircle(r):
    print("Area of Circle is:",2*3.14*r)
def circleper(r):
    print("Circle perimeter is:",3.14*r*r)