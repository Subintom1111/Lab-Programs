#Program to read file content and store to list

Openfile=open("Hello")
FileLines=Openfile.readlines()



# Without Strip

print("File Content Before Removing the Character: \n")
print(FileLines)

# Using Strip

print("\nFile content After Removing the Newline Character:\n")
FileLines=[x.strip() for x in FileLines]
print([x.strip() for x in FileLines])
Openfile.close()


