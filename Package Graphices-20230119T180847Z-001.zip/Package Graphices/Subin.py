import Graphics.Circle as a
r=int(input("Enter the Radius:"))
a.circleper(r)
a.areacircle(r)
import Graphics.Rectangle as c
l=int(input("Enter the Length:"))
b=int(input("Enter the Breadth:"))
c.arearect(l,b)
c.areaper(l,b)
import Graphics.graphics3D.Cuboid as d
l=int(input("Enter the Length:"))
w=int(input("Enter the Width:"))
h=int(input("Enter the Height:"))
d.arearCub(l,w,h)
d.areaper(l,w,h)
import Graphics.graphics3D.Sphere as e
r1=int(input("Enter the Radius:"))
e.areasphere(r)
