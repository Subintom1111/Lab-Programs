def areasphere(r):
    print("Area of sphere is:",4*3.14*r*r)