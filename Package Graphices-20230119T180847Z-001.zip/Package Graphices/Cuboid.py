def arearCub(l,w,h):
    print("Area of Cuboid is:",2*(w+w*h+l*h))
def areaper(l,w,h):
    print("Rectangle Cuboid is:",4*(l*w*h))